"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.smtpConfig = void 0;
exports.smtpConfig = {
    host: 'mail.agriland11971.c42.integrator.host',
    port: 465,
    secure: true,
    auth: {
        user: 'no-reply@agriland11971.c42.integrator.host',
        pass: 'Sponton3825.'
    }
};
